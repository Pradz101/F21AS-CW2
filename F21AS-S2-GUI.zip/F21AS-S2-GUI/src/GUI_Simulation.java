

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI_Simulation extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	/**
	 * Create the frame.
	 */
	public GUI_Simulation(OrderManager order) {
		setTitle("Coffee Shop");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 954, 655);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(70, 340, 313, -193);
		contentPane.add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(15, 71, 457, 420);
		contentPane.add(scrollPane_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane_1.setViewportView(textArea);
		
		JButton btnOpenCoffeeShop = new JButton("Open Coffee Shop");
		btnOpenCoffeeShop.setBounds(138, 505, 202, 29);
		contentPane.add(btnOpenCoffeeShop);
		
		btnOpenCoffeeShop.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				//textArea.append(order.readingthreadsorder());
				
			}
			
		});
		
		JLabel lblOrderQueue = new JLabel("Order Queue");
		lblOrderQueue.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 27));
		lblOrderQueue.setBounds(138, 32, 184, 33);
		contentPane.add(lblOrderQueue);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(498, 327, 417, -205);
		contentPane.add(scrollPane_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(498, 71, 417, 190);
		contentPane.add(scrollPane_3);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setEditable(false);
		scrollPane_3.setViewportView(textArea_1);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(498, 309, 417, 182);
		contentPane.add(scrollPane_4);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setEditable(false);
		scrollPane_4.setViewportView(textArea_2);
		
		JLabel lblWaiter = new JLabel("Waiter 1");
		lblWaiter.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblWaiter.setBounds(684, 43, 101, 22);
		contentPane.add(lblWaiter);
		
		JLabel lblWater = new JLabel("Waiter 2");
		lblWater.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblWater.setBounds(684, 277, 101, 34);
		contentPane.add(lblWater);
		
		JButton btnIncreaseSimulation = new JButton("Increase Simulation");
		btnIncreaseSimulation.setBounds(529, 524, 184, 43);
		contentPane.add(btnIncreaseSimulation);
		
		JButton btnSlowSimulation = new JButton("Slow Simulation");
		btnSlowSimulation.setBounds(728, 524, 168, 43);
		contentPane.add(btnSlowSimulation);
		
		JButton btnCreateLog = new JButton("Create Log");
		btnCreateLog.setBounds(182, 554, 115, 29);
		contentPane.add(btnCreateLog);
	}
}
