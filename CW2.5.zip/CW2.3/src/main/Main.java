package main;

import view.GUI_Simulation;

public class Main {

	public static void  main(String[] args){
		
			GUI_Simulation gui = new GUI_Simulation("", "");
			
			gui.setVisible(true);
		
	}
}
