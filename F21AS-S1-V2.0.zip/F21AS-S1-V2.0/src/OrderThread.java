import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class OrderThread extends Thread {
	
	static HashMap<String,Menu> itemList = new HashMap<String,Menu>();
	static List<String> itemIDList;
	static List<Order> orderList= new ArrayList<Order>();
	List<Order> mainOrderList= new ArrayList<Order>();
	
	static List<Order> orderListA= new ArrayList<Order>();
	static List<Order> orderListB= new ArrayList<Order>();
	
	static int c = 10; // order generator counter
	
	
	//static String file ="Items.csv";

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public void run() {
		count();
		try {
			
			start();
			if(Thread.currentThread().getName().equals("Thread-0")) {
				
				for(Order o:orderList) {
					if(o.getOrderIDno()%2 == 0)
					orderListA.add(o);
					System.out.println(Thread.currentThread().getName());
					System.out.println(o.getOrderInformation());
					Thread.sleep((long) o.getTotalTime());
				}
				
			}
			else if(Thread.currentThread().getName().equals("Thread-1")) {
				
				for(Order o:orderList) {
					if(o.getOrderIDno()%2 == 1) {
					orderListB.add(o);
					System.out.println(Thread.currentThread().getName());
					System.out.println(o.getOrderInformation());
					Thread.sleep((long) o.getTotalTime());
					}
				}
			}
				else if(Thread.currentThread().getName().equals("Thread-2")) {
					
					for(Order o:orderList) {
						mainOrderList.add(o);
						System.out.println(o.getOrderInformation());
						Thread.sleep(1500);
					}
					
					}
			Thread.sleep(1000);
				
			}
		catch(Exception e) {
			System.out.println(e);
		}
			}
	
	public void start() {
			for(String i:itemList.keySet()) {
			
			System.out.println(itemList.get(i).getItem_name());
			try {
				sleep((long) itemList.get(i).getItem_cost()*100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
			OrderGenerator oG = new OrderGenerator();
			
			orderList.add(oG.generateOrder(c));
			c=c+1;
			orderList.add(oG.generateOrder(c));
			
			OrderThread t1 = new OrderThread();
			OrderThread t2 = new OrderThread();
			
			t1.start();
			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			t2.start();
			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			t1.setName("Counter 1");    
	        t2.setName("Counter 2");
	}

	public static synchronized void count() {
		
		for (int i=1; i<=3;i++) {
			//System.out.println("Thread ("+Thread.currentThread().getId()+") = "+i);
		}
		
	}
}
