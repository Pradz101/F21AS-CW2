import java.text.DateFormat;

import java.text.SimpleDateFormat;

import java.util.Date;



public class Order

{
	String orderID;
	String itemID1, itemID2, itemID3, itemID4;
	int itemQ1, itemQ2, itemQ3, itemQ4;
	double totalTime;
	double totalCost;
	
	private String order_id;
    private Date order_timestamp;
    private String item_detail;
    private int item_quantity;
    private String customer_detail;
    private double rate;

	public Order(String order_id1, String item_id1, String item_id2, String item_id3, String item_id4,
			int item_quantity1, int item_quantity2, int item_quantity3, int item_quantity4,
			double totalTime,double totalCost) {
		orderID = order_id1;
		itemID1 = item_id1;
		itemID2 = item_id2;
		itemID3 = item_id3;
		itemID4 = item_id4;
		itemQ1 = item_quantity1;
		itemQ2 = item_quantity2;
		itemQ3 = item_quantity3;
		itemQ4 = item_quantity4;
		this.totalTime = totalTime;
		this.totalCost = totalCost;
	}

	public Order(String order_id, Date order_timestamp, String item_detail, int item_quantity, String customer_id,
			double rate) {
		 	this.order_id = order_id;
	    	this.order_timestamp = order_timestamp;
	        this.item_detail = item_detail;
	        this.item_quantity = item_quantity;
	        this.customer_detail = customer_detail;
	        this.rate = rate;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public String getOrderID() {
		return orderID;
	}
	
	public int getOrderIDno() {
		int n;
		char N= orderID.charAt(2);
		n = Integer.parseInt(String.valueOf(N));
		
		return n;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getItemID(int itemNo) {
		
		if(itemID1.equals("null"))
			setItemID1("       ");
		else if(itemID2.equals("null"))
			setItemID2("       ");
		else if(itemID3.equals("null"))
			setItemID3("       ");
		else if(itemID4.equals("null"))
			setItemID4("       ");
		
		switch(itemNo) {
		case 1:
			return itemID1;
		case 2:
			return itemID2;
		case 3:
			return itemID3;
		case 4:
			return itemID4;
		default:
			return "";
		}
	}

	public void setItemID1(String itemID1) {
		this.itemID1 = itemID1;
	}


	public void setItemID2(String itemID2) {
		this.itemID2 = itemID2;
	}

	public void setItemID3(String itemID3) {
		this.itemID3 = itemID3;
	}


	public void setItemID4(String itemID4) {
		this.itemID4 = itemID4;
	}

	public int getItemQ1() {
		return itemQ1;
	}

	public void setItemQ1(int itemQ1) {
		this.itemQ1 = itemQ1;
	}

	public int getItemQ2() {
		return itemQ2;
	}

	public void setItemQ2(int itemQ2) {
		this.itemQ2 = itemQ2;
	}

	public int getItemQ3() {
		return itemQ3;
	}

	public void setItemQ3(int itemQ3) {
		this.itemQ3 = itemQ3;
	}

	public int getItemQ4() {
		return itemQ4;
	}

	public void setItemQ4(int itemQ4) {
		this.itemQ4 = itemQ4;
	}

	public double getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(double totalTime) {
		this.totalTime = totalTime;
	}	

	
	public String getOrderInformation() {
		
		String orderInfo;
		
		orderInfo = "Order No. " + getOrderID()+"\n"+ getItemID(1) + " x "+ getItemQ1() +"\n"+ getItemID(2) + " x "+ getItemQ2()  
		+ "\n"+ getItemID(3)+ " x "+ getItemQ3() + "\n"+ getItemID(4) + " x "+ getItemQ4() + "\n\n"
		 +"Total Cost: " + getTotalCost()+" AED\n\n\n";
		
		return orderInfo;
	}
	
	public String getOrder_id() {return order_id;}
    public void setOrder_id(String order_id) {this.order_id = order_id;}

    public Date getOrder_timestamp() {return order_timestamp; }
    public void setOrder_timestamp(Date order_timestamp) {this.order_timestamp = order_timestamp;}

    public String getItem_detail() {return item_detail; }
    public void setItem_detail(String item_detail) {this.item_detail = item_detail; }

    public int getItem_quantity() { ;
    	return item_quantity;  }
    public void setItem_quantity(int item_quantity){this.item_quantity = item_quantity;}

    public String getCustomer_detail() { return customer_detail; }
    public void setCustomer_detail(String customer_detail) {this.customer_detail = customer_detail;}
    
    public void setRate(double rate) {this.rate= rate; }
    public double getRate() {
		return rate;
	}		
	
	
}