package org.eclipse.swt;

public class SWT {

}
